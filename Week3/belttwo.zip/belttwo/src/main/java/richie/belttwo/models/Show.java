package richie.belttwo.models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name="shows")
public class Show {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    @NotBlank(message="Title is required!")
    @Size(min=2, max=128, message="Title must be 2 or more characters!")
    private String title;

    @NotBlank(message="Network is required!")
    @Size(min=2, max=128, message="Network must be 2 or more characters!")
    private String network;

    @NotBlank(message="Description is required!")
    @Size(min=2, max=128, message="Description must have 2 or more characters!")
    private String description;

    
    @ManyToOne(fetch=FetchType.LAZY) //many to one for singular gets
    @JoinColumn(name="user_id") //many to one for singular gets
    private User user; //many to one for singular gets
    
    private Integer ratings = 0;
    
    @ManyToMany(fetch = FetchType.LAZY) 
    @JoinTable(
        name = "show_ratings", 
        joinColumns = @JoinColumn(name = "show_id"), 
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private List<User> raters; //named it upvoters as we're trying to track upvoters in this scenario.


    public Show() {
    }


    public Show(Long id, String title, String network, String description, User user, Integer ratings, List<User> raters) {
        this.id = id;
        this.title = title;
        this.network = network;
        this.description = description;
        this.user = user;
        this.ratings = ratings;
        this.raters = raters;
    }


    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNetwork() {
        return this.network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getRatings() {
        return this.ratings;
    }

    public void setRatings(Integer ratings) {
        this.ratings = ratings;
    }

    public List<User> getRaters() {
        return this.raters;
    }

    public void setRaters(List<User> raters) {
        this.raters = raters;
    }
}
