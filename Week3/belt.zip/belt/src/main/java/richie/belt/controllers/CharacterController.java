package richie.belt.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import richie.belt.models.Character;
import richie.belt.models.User;
import richie.belt.services.CharacterService;
import richie.belt.services.UserService;

@Controller
public class CharacterController {

    @Autowired
    CharacterService characterService;

    @Autowired
    UserService userService;

    // get for home
    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/logout";
        }
        User user = userService.getOneUser(userId);
        List<Character> characters = characterService.getAllCharacters();
        model.addAttribute("user", user);
        model.addAttribute("characters", characters);
        return "character/home.jsp";
    }

    // get for create
    @GetMapping("/names/new")
    public String addCharacter(@ModelAttribute("character") Character character, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }
        User user = userService.getOneUser(userId);
        // model.addAttribute("character", new Character());
        // model.addAttribute("user", user);
        return "character/newCharacter.jsp";
    }

    // create
    @PostMapping("/character/new")
    public String create(@Valid @ModelAttribute("character") Character character, BindingResult result,
            HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }
        User user = userService.getOneUser(userId);
        if (result.hasErrors()) {
            return "character/newCharacter.jsp";
        } else {
            character.setUser(user);
            characterService.createCharacter(character);
            return "redirect:/home";
        }
    }

    // upvote
    @PostMapping("/character/upvote/{id}")
    public String upvote(@PathVariable("id") Long id, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/";
        }
        Character character = characterService.getOneCharacter(id);
        List<User> upvoters = character.getUpvoters();
        if (upvoters.contains(currentUser)) {
            return "redirect:/home";
        }
    
        Integer upvotes = character.getUpvotes();
        if (upvotes == null) {
            upvotes = 0;
        }
        character.setUpvotes(upvotes + 1);
        upvoters.add(currentUser);
        characterService.updateCharacter(character);
    
        return "redirect:/home";
    }
    
    //get one for name
    @GetMapping("/character/{id}")
    public String viewOne(@PathVariable("id") Long id, Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/";
        }
            
        Character character = characterService.getOneCharacter(id);
        model.addAttribute("character", character);
        
        boolean hasUpvoted = characterService.hasUserUpvotedCharacter(currentUser, character);
        model.addAttribute("hasUpvoted", hasUpvoted);
    
        boolean canEdit = currentUser.getId().equals(character.getUser().getId());
        model.addAttribute("canEdit", canEdit);
        
        return "character/viewOne.jsp";
    }

    //edit
    @GetMapping("/character/{id}/edit")
    public String editCharacter(@PathVariable("id") Long id, Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/";
        }
        
        Character character = characterService.getOneCharacter(id);
        boolean isCurrentUser = currentUser.getId().equals(character.getUser().getId());
        
        model.addAttribute("character", character);
        model.addAttribute("user", currentUser);
        model.addAttribute("isCurrentUser", isCurrentUser);
        
        return "character/edit.jsp";
    }
    

@PostMapping("/character/{id}/editcharacter")
    public String updateCharacter(@PathVariable("id") Long id, @Valid @ModelAttribute("character") Character character, BindingResult result, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/";
        }
        
        Character existingCharacter = characterService.getOneCharacter(id);
        existingCharacter.setGender(character.getGender());
        existingCharacter.setOrigin(character.getOrigin());
        existingCharacter.setMeaning(character.getMeaning());
        
        if (result.hasErrors()) {
            return "character/edit.jsp";
        } else {
            characterService.updateCharacter(existingCharacter);
            return "redirect:/character/" + id;
        }
    }

    // delete
    @DeleteMapping("/character/{id}/delete")
    public String deleteCharacter(@PathVariable("id") Long id) {
        characterService.deleteCharacterById(id);
        return "redirect:/home";
    }
    
    
}
