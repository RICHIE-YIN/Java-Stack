package richie.dojosninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojosninjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojosninjasApplication.class, args);
	}

}
