package richie.booksapi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import richie.booksapi.models.Book;
import richie.booksapi.repositories.BookRepository;

@Controller
public class MainController {

    @Autowired BookRepository bookRepository; //connects book repository. BookRepository is class/object, bookRepository is the instance of that object of which you can call on and grab from DB

    // !CREATE

    //! READ ALL
    @GetMapping("/")
    public String index(Model model){ //Model model allows us to get stuff front the backend to the backend
        List<Book> books = bookRepository.findAll(); //by calling bookRepository we have a variety og=f methods of which we can call on
        // System.out.println(books); //in terminal it shows the list of books in your db
        model.addAttribute("books", books); //sends books down to models
        return "index.jsp";
    }

    // !READ ONE

    // !UPDATE

    // !DELETE
}
    