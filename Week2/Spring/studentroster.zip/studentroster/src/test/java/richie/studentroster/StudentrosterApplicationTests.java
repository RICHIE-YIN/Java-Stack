package richie.studentroster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentrosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
