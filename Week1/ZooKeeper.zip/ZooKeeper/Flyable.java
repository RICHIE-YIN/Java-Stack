package ZooKeeper;

public interface Flyable {
    public void fly();
}
