package ZooKeeper;

public interface Attack {
    public void attackTown();
}
