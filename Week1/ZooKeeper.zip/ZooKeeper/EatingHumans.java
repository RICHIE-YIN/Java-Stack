package ZooKeeper;

public interface EatingHumans {
    public void eatHumans();
}
