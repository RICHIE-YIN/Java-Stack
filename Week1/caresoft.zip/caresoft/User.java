package caresoft;

public class User {
    protected Integer id;
    protected int pin;
    
    // TO DO: Getters and setters
	// Implement a constructor that takes an ID

    public User(Integer id) {
        this.id = id;
    }

}
